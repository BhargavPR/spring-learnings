package com.example.mongodbcrudapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MongoDbCrudAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
